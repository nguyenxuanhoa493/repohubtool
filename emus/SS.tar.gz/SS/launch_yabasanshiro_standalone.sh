#!/bin/sh
echo $0 $*
SA_DIR=/mnt/SDCARD/Emus/SS/yabasanshiro
EMU_DIR=/mnt/SDCARD/Emus/SS

cd $EMU_DIR
$EMU_DIR/cpufreq.sh
$EMU_DIR/cpuswitch.sh


#disable netplay
NET_PARAM=

cd $SA_DIR
#for libpng16
export LD_LIBRARY_PATH=$SA_DIR:$LD_LIBRARY_PATH
./pic2fb loading.png
HOME=$SA_DIR ./yabasanshiro -r 3 -b saturn_bios.bin -i "$*"
