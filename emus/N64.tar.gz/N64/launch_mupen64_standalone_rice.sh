#!/bin/sh
echo $0 $*
SA_DIR=/mnt/SDCARD/Emus/N64/mupen64plus_sa
EMU_DIR=/mnt/SDCARD/Emus/N64

$EMU_DIR/cpufreq.sh
$EMU_DIR/cpuswitch.sh

cd $SA_DIR/

#disable netplay
NET_PARAM=
export LD_LIBRARY_PATH=$SA_DIR:$LD_LIBRARY_PATH
./pic2fb loading.png
touch /tmp/trimui_inputd/input_dpad_to_joystick
HOME=$SA_DIR/ ./mupen64plus --resolution 1024x768 --gfx mupen64plus-video-rice.so "$*"
